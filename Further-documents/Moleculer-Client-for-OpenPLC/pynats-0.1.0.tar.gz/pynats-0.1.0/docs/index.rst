*************************************
pynats - A Python client for the NATS
*************************************

.. automodule:: pynats
   :members: Connection
